# FUOYE Events Management System Footer

A responsive footer recreated from the provided FUOYE Events Management System screenshot using:

- HTML5
- CSS3
- Vanilla JavaScript

## Files

- `index.html` — footer structure and demo page
- `style.css` — responsive styling
- `script.js` — dynamic copyright year and smooth internal links

## GitHub

Upload all three files to your repository. If this is part of an existing website, copy the `<footer class="site-footer">...</footer>` section into your page and link:

```html
<link rel="stylesheet" href="style.css">
<script src="script.js"></script>
```

## Customization

Replace the CSS logo placeholder in `.logo-box` with the actual FUOYE logo image if you have it.

Update the `href` values in `index.html` so they point to the real pages of your project.
