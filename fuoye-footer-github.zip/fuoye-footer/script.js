// FUOYE Events Management System - Footer JavaScript

document.addEventListener("DOMContentLoaded", () => {
  // Keep the copyright year automatically updated.
  const yearElement = document.getElementById("currentYear");

  if (yearElement) {
    yearElement.textContent = new Date().getFullYear();
  }

  // Smoothly handle internal footer links.
  document.querySelectorAll('.site-footer a[href^="#"]').forEach((link) => {
    link.addEventListener("click", (event) => {
      const targetId = link.getAttribute("href");
      const target = document.querySelector(targetId);

      // If the target section does not exist yet, leave the link alone.
      if (!target) return;

      event.preventDefault();

      target.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    });
  });
});
